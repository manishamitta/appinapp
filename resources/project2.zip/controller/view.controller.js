sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("project2.controller.view",{onInit:function(){}})});
//# sourceMappingURL=view.controller.js.map